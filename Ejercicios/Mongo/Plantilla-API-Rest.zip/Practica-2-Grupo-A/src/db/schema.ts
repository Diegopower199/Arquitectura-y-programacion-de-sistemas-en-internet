import { ObjectId } from "mongo";


/*export type schema1 = Omit<tipo1, "id"> & {
    _id: ObjectId;
};*/
