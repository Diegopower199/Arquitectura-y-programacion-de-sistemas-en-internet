
/*export type tipo1 = {
    id: string,
}*/