import { ObjectId } from "mongo";
import { tipo1 } from "../types.ts";

export type schema1 = Omit<tipo1, "id"> & {
    _id: ObjectId;
};
