import { gql } from "graphql_tag";

export const typeDefs = gql`

type Planet {
  name: String!
  rotation_period: String!
  orbital_period: String!
  diameter: String!
  climate: String!
  gravity: String!
  terrain: String!
  surface_water: String!
  population: String!
  residents: [People!]!
  films: [Film!]!
  created: String!
  edited: String!
  url: String!
}

type People {
  name: String!
  height: String!
  mass: String!
  hair_color: String!
  skin_color: String!
  eye_color: String!
  birth_year: String!
  gender: String!
  homeworld: String!
  films: [Film!]!
  species: [String!]!
  vehicles: [String!]!
  starships: [String!]!
  created: String!
  edited: String!
  url: String!
}

type Film {
  title: String!
  episode_id: String!
  opening_crawl: String!
  director: String!
  producer: String!
  release_date: String!
  characters: [People!]!
  planets: [Planet!]!
  starships: [String!]!
  vehicles: [String!]!
  species: [String!]!
  created: String!
  edited: String!
  url: String!
}

  type Query {
    planets (page: Int!): [Planet!]!
  }
`;
