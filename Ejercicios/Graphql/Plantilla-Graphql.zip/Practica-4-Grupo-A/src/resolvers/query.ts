

export const Query = {
  
};

/*
ejemplo: async (_: unknown, args: {}): Promise<Tipo1> => {

}
*/