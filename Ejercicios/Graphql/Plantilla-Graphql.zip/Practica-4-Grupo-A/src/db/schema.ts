import { ObjectId } from "mongo";


/*export type Tipo1Schema = Omit<Tipo1, "id"> & {
    _id: ObjectId,
}*/