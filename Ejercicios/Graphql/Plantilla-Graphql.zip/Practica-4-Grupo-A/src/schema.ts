import { gql } from "graphql_tag";

export const typeDefs = gql`



type Query {
    
}

type Mutation {
    
}
`;
