import { ObjectId } from "mongo";

/*export type Tipo1 = {
    id: string,
}*/