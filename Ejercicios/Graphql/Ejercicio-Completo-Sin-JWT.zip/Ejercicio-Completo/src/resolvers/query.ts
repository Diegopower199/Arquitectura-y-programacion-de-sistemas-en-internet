

export const Query = {
    
  
};
