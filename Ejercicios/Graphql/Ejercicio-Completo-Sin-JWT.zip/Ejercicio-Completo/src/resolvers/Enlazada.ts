

export const Enlazada = {
  
};
